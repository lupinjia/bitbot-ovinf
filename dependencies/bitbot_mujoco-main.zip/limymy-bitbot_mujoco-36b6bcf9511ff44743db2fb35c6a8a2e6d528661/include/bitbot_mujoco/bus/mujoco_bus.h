#pragma once

#include "bitbot_kernel/bus/bus_manager.hpp"
#include "bitbot_mujoco/device/mujoco_device.hpp"

namespace bitbot{

  class MujocoBus : public BusManagerTpl<MujocoBus, MujocoDevice>
  {
  public:
    MujocoBus(/* args */);
    ~MujocoBus();

    void SetMujocoParam(const mjModel *m, mjData *d);

    void ReadBus();
    void WriteBus();

    void UpdateDevices();

    const mjModel* GetMujocoModel() const;
    mjData * GetMujocoData() const;

  protected:
    void doConfigure(const pugi::xml_node& bus_node);
    void doRegisterDevices();

  private:

    const mjModel *mj_m_ = nullptr;
    mjData *mj_d_ = nullptr;
  };
  

}
