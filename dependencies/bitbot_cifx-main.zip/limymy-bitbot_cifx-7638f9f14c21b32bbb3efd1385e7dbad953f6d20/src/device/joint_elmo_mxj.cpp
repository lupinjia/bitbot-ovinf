#include "bitbot_cifx/device/joint_elmo_mxj.h"
#include "bitbot_kernel/utils/time_func.h"
#include "bitbot_cifx/bus/canopen.h"
#include "bitbot_cifx/bus/cifx/protocol_SDO.h"

namespace bitbot
{
  JointElmoMXJ::JointElmoMXJ(const pugi::xml_node& motor_node)
    : CifxJoint(motor_node)
  {
    constexpr double deg2rad = M_PI/180.0;

    basic_type_ = static_cast<uint32_t>(BasicDeviceType::MOTOR);
    type_ = static_cast<uint32_t>(CifxDeviceType::JOINT_ELMO_MXJ);  // cifx_device.hpp中需要登记
    input_data_length_ = 14;
    output_data_length_ = 14;

    monitor_header_.headers = {"status","mode","actual_position", "target_position", "actual_velocity","target_velocity","actual_current","target_torque"};
    monitor_data_.resize(monitor_header_.headers.size());

    std::string mode;
    ConfigParser::ParseAttribute2s(mode, motor_node.attribute("mode"));
    if(mode.compare("CSP") == 0)
    {
      joint_data_.config.mode = static_cast<int>(CANopenMotorMode::CSP);
    }
    else if(mode.compare("CST") == 0)
    {
      joint_data_.config.mode = static_cast<int>(CANopenMotorMode::CST);
    }else if(mode.compare("CSV") == 0)
    {
      joint_data_.config.mode = static_cast<int>(CANopenMotorMode::CSV);
    }

    this->InitParams();
    ConfigParser::ParseAttribute2d(mxj_zero_pos_x_, motor_node.attribute("zero_pos_x_angle"));
    mxj_zero_pos_x_ *= deg2rad;
    ConfigParser::ParseAttribute2d(mxj_offset_pos_, motor_node.attribute("offset_pos"));
    mxj_offset_pos_ *= deg2rad;
    ConfigParser::ParseAttribute2d(mxj_l1_, motor_node.attribute("l1"));
    ConfigParser::ParseAttribute2d(mxj_l2_, motor_node.attribute("l2"));
    ConfigParser::ParseAttribute2d(mxj_l3_, motor_node.attribute("l3"));
    ConfigParser::ParseAttribute2d(mxj_l4_, motor_node.attribute("l4"));
    ConfigParser::ParseAttribute2d(mxj_l5_, motor_node.attribute("l5"));
    ConfigParser::ParseAttribute2d(mxj_l6_, motor_node.attribute("l6"));
    if(mxj_l1_ == 0||mxj_l2_ == 0||mxj_l3_ == 0||mxj_l4_ == 0||mxj_l5_ == 0||mxj_l6_ == 0)
    {
      logger_->error("please check MXJ_L of MXJ:{}", name_);
      abort();
    }
    ConfigParser::ParseAttribute2d(mxj_efficiency_, motor_node.attribute("efficiency"));

    ConfigParser::ParseAttribute2d(mxj_lead_, motor_node.attribute("lead"));
    if(mxj_lead_ == 0)
    {
      logger_->error("please set param lead of pushrod:{}", name_);
      abort();
    }

    ConfigParser::ParseAttribute2d(delta_l4_, motor_node.attribute("delta_l4"));
    delta_l4_ *= deg2rad;
    ConfigParser::ParseAttribute2d(delta_l5_, motor_node.attribute("delta_l5"));
    delta_l5_ *= deg2rad;
    ConfigParser::ParseAttribute2d(delta_link_, motor_node.attribute("delta_link"));
    delta_link_ *= deg2rad;
    ConfigParser::ParseAttribute2d(delta_phi3_, motor_node.attribute("delta_phi3"));
    delta_phi3_ *= deg2rad;
    ConfigParser::ParseAttribute2d(mxj_motor_direction_, motor_node.attribute("mxj_motor_direction"));
    ConfigParser::ParseAttribute2d(mxj_joint_dircetion_, motor_node.attribute("mxj_joint_direction"));

    // 计算零位时的初始推杆长度
    mxj_pushrod_lenth0_ = JointSetLenth0();
    // logger_->debug("initial len: {}", pushrod_initial_len_);
  }

  void JointElmoMXJ::InitSDO()
  {
    SetMotorRateTorque(id_, joint_data_.config.current_ratio);
    SleepMS(50);
    logger_->debug("joint {}(id {}) TorqueRate: {}", name_, id_, ReadMotorRateTorque(id_));
    SleepMS(50);
    SetMotorRateCurrent(id_, joint_data_.config.current_ratio);
    SleepMS(50);
    logger_->debug("joint {}(id {}) CurrentRate: {}", name_, id_, ReadMotorRateCurrent(id_));
  }
  
  void JointElmoMXJ::InitParams()
  {
    joint_data_.config.current_ratio = 10000;
    PowerOff();
    SetMode(static_cast<CANopenMotorMode>(joint_data_.config.mode));
    SetTargetVelocity(0);
    SetTargetTorque(0);
  }

  JointPowerOnState JointElmoMXJ::PowerOn()
  {
    using namespace ds402;

    constexpr int step_start = 0;
    constexpr int step_ready_to_switch_on = 1;
    constexpr int step_switch_on = 2;
    constexpr int step_enable_oprational = 3;
    constexpr int step_finish = 4;

    static int waiting_count = 0;

    // 位置参数复位
    this->SetTargetPosition(this->GetActualPosition());

    switch (poweron_step_)
    {
    case step_start:
      poweron_step_++;
      waiting_count = 0;
      break;
    case step_ready_to_switch_on:
      ReadyToSwitchOn(reinterpret_cast<uint16_t*>(bus_send_data_.data()+elmo_send_addr.control_word));
      if(isReadyToSwitchOn(*reinterpret_cast<uint16_t*>(bus_receive_data_.data()+elmo_input_addr.status_word)))
      {
        poweron_step_++;
        waiting_count = 0;
      }
      else
      {
        waiting_count++;
        if(waiting_count > 30)
        {
          logger_->error("motor(id{}) is not ready to switch on", id_);
          return JointPowerOnState::Error;
        }
      }
      break;
    case step_switch_on:
      SwitchOn(reinterpret_cast<uint16_t*>(bus_send_data_.data()+elmo_send_addr.control_word));
      if(isSwitchedOn(*reinterpret_cast<uint16_t*>(bus_receive_data_.data()+elmo_input_addr.status_word)))
      {
        poweron_step_++;
        waiting_count = 0;
      }
      else
      {
        waiting_count++;
        if(waiting_count > 30)
        {
          logger_->error("motor(id{}) does not switch on", id_);
          return JointPowerOnState::Error;
        }
      }
      break;
    case step_enable_oprational:
      EnableOperational(reinterpret_cast<uint16_t*>(bus_send_data_.data()+elmo_send_addr.control_word));
      if(isOperationEnabled(*reinterpret_cast<uint16_t*>(bus_receive_data_.data()+elmo_input_addr.status_word)))
      {
        poweron_step_++;
        waiting_count = 0;
      }
      else
      {
        waiting_count++;
        if(waiting_count > 30)
        {
          logger_->error("motor(id{}) is not operation_enabled", id_);
          return JointPowerOnState::Error;
        }
      }
      break;
    case step_finish:
      return JointPowerOnState::Finish;
      break;
    default:
      break;
    }
    return JointPowerOnState::Running;
  }

  void JointElmoMXJ::ResetFault()
  {
    ds402::ResetFault(reinterpret_cast<uint16_t*>(bus_send_data_.data()+elmo_send_addr.control_word));
  }

  void JointElmoMXJ::PowerOff()
  {
    ds402::ShutDown(reinterpret_cast<uint16_t*>(bus_send_data_.data()+elmo_send_addr.control_word));
  }

  void JointElmoMXJ::SetMode(CANopenMotorMode mode)
  {
    this->doSetMode(static_cast<int16_t>(mode));
  }

  void JointElmoMXJ::SetMode(int mode)
  {
    this->doSetMode(static_cast<int16_t>(mode));
  }

  void JointElmoMXJ::doSetMode(int16_t target_mode)
  {
    joint_data_.config.mode = target_mode;

    std::memcpy(bus_send_data_.data()+elmo_send_addr.mode, &target_mode, sizeof(int16_t));
  }

  void JointElmoMXJ::SetTargetPosition(double position)
  {
    static int32_t count = 0;
    joint_data_.runtime.target_pos = position;

    if(position > joint_data_.config.pos_max)
      position = joint_data_.config.pos_max;
    else if(position < joint_data_.config.pos_min)
      position = joint_data_.config.pos_min;

    count = EncoderAngle2Count(JointPos2MotorPos(position - mxj_offset_pos_));
    std::memcpy(bus_send_data_.data()+elmo_send_addr.target_position, &count, sizeof(int32_t));
  }

  void JointElmoMXJ::SetTargetVelocity(double velocity)
  {
    static int32_t count = 0;
    joint_data_.runtime.target_velocity = velocity;

    count = EncoderCounts2Rads(JointVel2MotorVel(velocity));
    std::memcpy(bus_send_data_.data()+elmo_send_addr.target_velocity, &count, sizeof(int32_t));
  }

  void JointElmoMXJ::SetTargetTorque(double torque)
  {
    joint_data_.runtime.target_torque = torque;
    
    SetTargetCurrent(Torque2Current(JointTorque2MotorTorque(torque)));
  }

  void JointElmoMXJ::SetTargetCurrent(double current)
  {
    static int16_t value = 0;
    static const double factor = 1000000/joint_data_.config.current_ratio;

    if(current > joint_data_.config.current_max)
      current = joint_data_.config.current_max;
    else if(current < joint_data_.config.current_min)
      current = joint_data_.config.current_min;

    joint_data_.runtime.target_current = current;

    value = current * factor;
    std::memcpy(bus_send_data_.data()+elmo_send_addr.target_torque, &value, sizeof(int16_t));
  }

  void JointElmoMXJ::UpdateRuntimeData()
  {
    constexpr double rad2deg = 180.0/M_PI;
    // "status","mode","actual_position","target_position","actual_velocity","target_velocity","actual_current","target_current"
    monitor_data_[0] = joint_data_.runtime.status;
    monitor_data_[1] = joint_data_.runtime.actual_mode;
    monitor_data_[2] = joint_data_.runtime.actual_pos * rad2deg;
    monitor_data_[3] = joint_data_.runtime.target_pos * rad2deg;
    monitor_data_[4] = joint_data_.runtime.actual_velocity * rad2deg;
    monitor_data_[5] = joint_data_.runtime.target_velocity * rad2deg;
    monitor_data_[6] = joint_data_.runtime.actual_current;
    monitor_data_[7] = joint_data_.runtime.target_torque;
  }

}
