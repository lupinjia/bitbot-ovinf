#ifndef _CIFX_VARIABLE_H
#define _CIFX_VARIABLE_H

#include <cifx/cifXUser.h>
#include <stdbool.h>

extern CIFXHANDLE cifx_driver;
extern int32_t	 	cifx_return_val;
extern CIFXHANDLE cifx_channel;

#endif // _CIFX_VARIABLE_H
