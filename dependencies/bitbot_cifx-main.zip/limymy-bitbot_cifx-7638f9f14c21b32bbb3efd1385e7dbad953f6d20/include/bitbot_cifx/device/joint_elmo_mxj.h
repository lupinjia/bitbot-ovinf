#pragma once

#include "bitbot_cifx/device/cifx_joint.hpp"
#include "bitbot_cifx/device/canopen_motor.hpp"

namespace bitbot
{

  class JointElmoMXJ final: public CifxJoint
  {
  public:
    JointElmoMXJ(const pugi::xml_node& motor_node);
    virtual ~JointElmoMXJ() = default;

    virtual void InitSDO() final override;

    inline virtual void Input(void* bus_data) final override
    {
      const float current_ratio = joint_data_.config.current_ratio / 1000.0 / 1000.0;
      // printf("receive: ");
      // for(uint16_t i = 0; i<16; i++)
      // {
      //   printf("%02x ", *((unsigned char*)(bus_data)+i));
      // }
      // printf("\n");

      std::memcpy(bus_receive_data_.data(), bus_data, 14);
      
      std::memcpy(&joint_data_.runtime.status, bus_receive_data_.data()+elmo_input_addr.status_word, sizeof(uint16_t));

      std::memcpy(&joint_data_.runtime.actual_mode, bus_receive_data_.data()+elmo_input_addr.mode, sizeof(int16_t));

      int32_t encoder;
      std::memcpy(&encoder, bus_receive_data_.data()+elmo_input_addr.position, sizeof(int32_t));
      motor_pos_ = EncoderCount2Angle(encoder);

      std::memcpy(&encoder, bus_receive_data_.data()+elmo_input_addr.velocity, sizeof(int32_t));
      motor_vel_ = EncoderCounts2Rads(encoder);

      int16_t current;
      std::memcpy(&current, bus_receive_data_.data()+elmo_input_addr.current, sizeof(int16_t));
      joint_data_.runtime.actual_current = current * current_ratio;
      
      motor_torque_ = Current2Torque(joint_data_.runtime.actual_current);

      MXJ_MotorParams2JointParams();
    }
    
    inline virtual void* Output() final override
    {
      return bus_send_data_.data();
    }

    virtual void ResetFault() final override;
    virtual JointPowerOnState PowerOn() final override;
    virtual void PowerOff() final override;

    void SetMode(CANopenMotorMode mode);
    virtual void SetMode(int mode) final override;

    virtual void SetTargetPosition(double position) final;

    void SetTargetVelocity(double velocity);

    /**
     * @brief 设置电机力矩。对于Elmo驱动器，目标力矩与目标电流相同，单位A
     * 
     * @param torque 
     */
    void SetTargetTorque(double torque);

    /**
     * @brief 设置电机电流，单位A
     * 
     * @param current 
     */
    void SetTargetCurrent(double current);

    virtual void UpdateRuntimeData() final override;

  private:
    void InitParams();
    void doSetMode(int16_t target_mode);
    // void MotorParams2JointParams()
    // {
    //   MotorParams2PushrodParams();
    //   PushrodParams2JointParams();
    // }
    double MXJ_FL_Phi1toPhi3(double Phi1)
    {
      double L1 = mxj_l1_;
      double L2 = mxj_l2_;
      double L3 = mxj_l3_;
      double L4 = mxj_l4_;

      if (L1 == L2 && L2 == L3 && L3 == L4)
      {
        return Phi1;
      }

      double A3 = L4 - L1 * std::cos(Phi1);
      double B3 = -L1 * std::sin(Phi1);
      double C3 = (std::pow(A3,2) + std::pow(B3,2) + std::pow(L3,2) - std::pow(L2,2)) / (2 * L3);

      //////////// C3 = (A3 ^ 2 + B3 ^ 2 + L3 ^ 2 - L2 ^ 2) / (2 * L3);

      double temp3 = (B3 + std::sqrt( std::pow(A3,2) + std::pow(B3,2) - std::pow(C3,2) )) / (A3 - C3);
      double Phi3 = 2 * std::atan(temp3);
      return Phi3;
    }

    double MXJ_FL_Phi1toFL_RD(double Phi1)
    {
        double L1 = mxj_l1_;
        double L2 = mxj_l2_;
        double L3 = mxj_l3_;
        double L4 = mxj_l4_;

        double A3 = L4 - L1 * std::cos(Phi1);
        double B3 = -L1 * std::sin(Phi1);
        double C3 = (std::pow(A3, 2) + std::pow(B3, 2) + std::pow(L3, 2) - std::pow(L2, 2)) / (2 * L3);

        //////////// C3 = (A3 ^ 2 + B3 ^ 2 + L3 ^ 2 - L2 ^ 2) / (2 * L3);

        double temp3 = (B3 + std::sqrt(std::pow(A3, 2) + std::pow(B3, 2) - std::pow(C3, 2))) / (A3 - C3);
        double Phi3 = 2 * std::atan(temp3);

        double dPhi1 = 2 * L3 * L4 * std::sin(Phi3) + 2 * L1 * L3 * std::sin(Phi1 - Phi3);
        double dPhi3 = 2 * L1 * L4 * std::sin(Phi1) + 2 * L1 * L3 * std::sin(Phi1 - Phi3);
        double FL_RD = dPhi1 / dPhi3;
        return FL_RD;
    }

    double MXJ_FL_Phi3toPhi1(double Phi3)
    {
        double L1 = mxj_l1_;
        double L2 = mxj_l2_;
        double L3 = mxj_l3_;
        double L4 = mxj_l4_;

        double A1 = L4 + L3 * std::cos(Phi3);
        double B1 = L3 * std::sin(Phi3);
        double C1 = (std::pow(A1,2) + std::pow(B1,2) + std::pow(L1,2) - std::pow(L2,2)) / (-2 * L1);

        double temp1 = (B1 + std::sqrt(std::pow(A1,2) + std::pow(B1,2) - std::pow(C1,2))) / (A1 - C1);

        double Phi1 = 2 * std::atan(temp1);

        if (Phi1 < 0)
          Phi1 = Phi1 + 2 * M_PI;
        
        return Phi1;
    }
    void MXJ_MotorParams2JointParams()
    {
        // Parameters Data map
        double L5 = mxj_l5_;
        double L6 = mxj_l6_;

        double delta_L4 = delta_l4_;
        double delta_L5 = delta_l5_;
        double delta_Link = delta_link_;
        double delta_Phi3 = delta_phi3_;

        double Q = mxj_lead_;
        double Motor_direction = mxj_motor_direction_;
        double TG_Lenth0 = mxj_pushrod_lenth0_;

        double Zero_pos_x_angle = mxj_zero_pos_x_;
        double Joint_Encoder_direction = mxj_joint_dircetion_;
        // Calculate
        double delta_L4_x = delta_L4 - delta_L5;
        double TG_temp = - motor_pos_ / (Motor_direction * 2 * M_PI) * Q;
        double TG_Lenth = TG_Lenth0 + TG_temp;
        mxj_pushrod_lenth_ = TG_Lenth;

        double Angle56_temp = std::acos((std::pow(L5,2) + std::pow(L6,2) - std::pow(TG_Lenth,2)) / (2 * L5 * L6));

        double Phi1 = M_PI - Angle56_temp + delta_Link + delta_L4;

        double Phi3 = MXJ_FL_Phi1toPhi3(Phi1);
        double Link_Angle = M_PI - Phi3 + delta_Phi3 + delta_L4_x;
        double Joint_Encoder_angle = Joint_Encoder_direction * (M_PI - Zero_pos_x_angle - Link_Angle);


        double FL_RD = MXJ_FL_Phi1toFL_RD(Phi1);
        mxj_fl_ratio_ = FL_RD;
        double TG_RD = L5 / TG_Lenth * sin(Angle56_temp) * L6 * 2 * M_PI / Q;
        mxj_tg_ratio_ = TG_RD;
        double RDratio = TG_RD * FL_RD;
        mxj_ratio_ = RDratio;
        // OutPut Data Map
        joint_data_.runtime.actual_pos = Joint_Encoder_angle + mxj_offset_pos_;

        joint_data_.runtime.actual_torque = motor_torque_ * mxj_ratio_;

        joint_data_.runtime.actual_velocity = motor_vel_ / mxj_ratio_;
    }

    double JointSetLenth0()
    {
        // Parameters Data map
        double L5 = mxj_l5_;
        double L6 = mxj_l6_;

        double delta_L4 = delta_l4_;
        double delta_L5 = delta_l5_;
        double delta_Link = delta_link_;
        double delta_Phi3 = delta_phi3_;

        double Q = mxj_lead_;
        double Motor_direction = mxj_motor_direction_;
        double TG_Lenth0 = mxj_pushrod_lenth0_;

        double Zero_pos_x_angle = mxj_zero_pos_x_;
        double Joint_Encoder_direction = mxj_joint_dircetion_;
        // Calculate
        double delta_L4_x = delta_L4 - delta_L5;
        double Phi30 = Zero_pos_x_angle + delta_Phi3 + delta_L4_x;

        double Phi1 = MXJ_FL_Phi3toPhi1(Phi30);

        double Angle56_temp = M_PI - Phi1 + delta_Link + delta_L4;

        double TG_Lenth0_temp = std::sqrt(std::pow(L5, 2) + std::pow(L6, 2) - 2 * L5 * L6 * std::cos(Angle56_temp));

        return TG_Lenth0_temp;
    }

    double JointPos2MotorPos(double joint_pos)// joint_pos 在输入时已经过joint_offset_pos_修正，即 joint_pos = joint_SetTargetPosition + joint_offset_pos_
    {
        // Parameters Data map
        double L5 = mxj_l5_;
        double L6 = mxj_l6_;

        double delta_L4 = delta_l4_;
        double delta_L5 = delta_l5_;
        double delta_Link = delta_link_;
        double delta_Phi3 = delta_phi3_;

        double Q = mxj_lead_;
        double Motor_direction = mxj_motor_direction_;
        double TG_Lenth0 = mxj_pushrod_lenth0_;

        double Zero_pos_x_angle = mxj_zero_pos_x_;
        double Joint_Encoder_direction = mxj_joint_dircetion_;
        // Calculate
        double delta_L4_x = delta_L4 - delta_L5;
        double Link_Angle = M_PI - Zero_pos_x_angle - Joint_Encoder_direction * joint_pos;

        double Phi3 = M_PI - Link_Angle + delta_Phi3 + delta_L4_x;

        double Phi1= MXJ_FL_Phi3toPhi1(Phi3);

        double Angle56_temp = M_PI - Phi1 + delta_Link + delta_L4;

        double TG_Lenth = std::sqrt(std::pow(L5,2) + std::pow(L6,2) - 2 * L5 * L6 * std::cos(Angle56_temp));

        double Motor_Encoder_angle = -Motor_direction * (TG_Lenth - TG_Lenth0) / Q * 2 * M_PI;

        return Motor_Encoder_angle;
    }

    double JointVel2MotorVel(double joint_vel)
    {
      double mxj_motor_vel = joint_vel * mxj_ratio_;
      return mxj_motor_vel;
    }
    double JointTorque2MotorTorque(double joint_torque)
    {
      double mxj_motor_torque = joint_torque / mxj_ratio_;
      return (mxj_motor_torque/ mxj_efficiency_);
    }

    /*
    uint16_t control_word
    int16_t mode
    int16_t  torque
    int32_t  position
    int32_t  target_velocity
    */

    static struct ElmoSendAddr
    {
      static constexpr uint16_t control_word = 0;
      static constexpr uint16_t mode = 2;			//01-P/3-V/4-T/08-SP/09-SV/0A-ST
      static constexpr uint16_t target_torque = 4;
      static constexpr uint16_t target_position = 6;
      static constexpr uint16_t target_velocity = 10;
    } elmo_send_addr;

    /*
    uint16_t status_word;
    int16_t  mode;			//01-P/3-V/4-T/08-SP/09-SV/0A-ST
    int32_t  position;
    int32_t  velocity;
    int16_t  current;
    */

    static struct ElmoInputAddr
    {
      static constexpr uint16_t status_word = 0;
      static constexpr uint16_t mode = 2;			
      static constexpr uint16_t position = 4;
      static constexpr uint16_t velocity = 8;
      static constexpr uint16_t current = 12;
    } elmo_input_addr;

    std::array<uint8_t, 14> bus_receive_data_{0};
    std::array<uint8_t, 14> bus_send_data_{0};

    int poweron_step_ = 0;

    double motor_pos_;
    double motor_vel_;
    double motor_torque_;
    // MXJ Mech Parameters
    double mxj_lead_ = 10.0;
    double mxj_l1_;
    double mxj_l2_;
    double mxj_l3_;
    double mxj_l4_;
    double mxj_l5_;
    double mxj_l6_;
    double delta_l4_ = 0;
    double delta_l5_ = 0;
    double delta_link_ = 0;
    double delta_phi3_ = 0;
    double mxj_motor_direction_ = 1;
    double mxj_joint_dircetion_ = 1;
    // 计算值
    double mxj_pushrod_lenth0_ = 0;// 推杆初始长度
    double mxj_pushrod_lenth_;
    double mxj_fl_ratio_;
    double mxj_tg_ratio_;
    double mxj_ratio_;
    // MXJ Zero Position
    double mxj_zero_pos_x_ = 0;
    double mxj_offset_pos_ = 0;
    //  Parameters
    double mxj_efficiency_ = 1.0;
    
    static constexpr double n_2pi_ = 2*M_PI; // 2pi
    static constexpr double n_1_2pi_ = 0.5*M_1_PI; // 1/2pi
  };

}
